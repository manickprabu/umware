<?php


include "com/2gyms/core.php";
include "com/2gyms/participant.php";
include "com/2gyms/resources.php";
include "com/2gyms/news_feed.php";
include "com/model/constants.php";


$list = '{"target":"LIST", "campaignId":"1"}';
$login = '{"target":"LOGIN", "email":"test", "password":"111"}';
$join = '{"target":"JOIN", "screenName":"ddd555", "fullName":"dddd", "email":"test1@5test.com", "password":"123", "bio":"biodata"}';
$update = '{"target":"UPDATE", "id":"2", "screenName":"Prabu Manic", "fullName":"Prabu Manickam",  "password":"111", "bio":"PM BIO"}'; //"email":"test@5test.com",



$participant = new Participant(  );
$target = $participant->target();


switch($target) {
	case "LOGIN":
		$participant->login();
		echo $participant->trace();
		break;
	
	case "JOIN":
		$participant->create();
		echo $participant->trace();
		break;
	
	case "UPDATE":
		$participant->update();
		echo $participant->trace();
		break;
	
	case "LIST"://list by campaignId
		$participant->getList();
		echo $participant->trace();
		break;
}
 

?>