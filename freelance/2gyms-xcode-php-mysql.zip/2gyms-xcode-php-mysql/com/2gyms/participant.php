<?php

class Participant extends Core
{
   public $id = "";
   public $fullName = "";
   public $screenName  = "";
   public $email = "";
   public $bio = "";
   public $password = "";
   public $photoList = "";
   public $photo = "aish.jpg";//"no-photo.png";
   
   private $campaignId = '';
   private $resource;
      
	function Participant($test='') {
		parent::__construct();
		$this->responce = new Responce();
		$this->resource = new Resources();
		
		$this->read($test);
	}

	function read($test) {
		$input = parent::read($test);
		
		if($input)
		{
			if( property_exists($input, "target") ) 		$this->target = $input->{'target'};
			
			if( property_exists($input, "email") ) 		$this->email = $input->{'email'};
			if( property_exists($input, "password") ) 	$this->password = $input->{'password'}; 
			
			if( property_exists($input, "id") ) 			$this->id = $input->{'id'};
			if( property_exists($input, "fullName") ) 	$this->fullName = $input->{'fullName'};
			if( property_exists($input, "screenName") ) $this->screenName = $input->{'screenName'}; 
			if( property_exists($input, "bio") ) 		$this->bio = $input->{'bio'}; 
			
			if( property_exists($input, "campaignId") ) 	$this->campaignId = $input->{'campaignId'};
		}
	}
	
	function load($select) 
	{
		while($row = mysql_fetch_array($select))
		  { 
		  	$this->bio = $row['Bio'];
			$this->email = $row['Email'];
			$this->fullName = $row['FullName'];
			$this->id = $row['Id'];
			$this->screenName = $row['ScreenName'];
			$this->password = $row['Password'];
			
			$this->photoList = $this->resource->participantPhotoList( $row['Id'] );
		  }
	}
	
	function getList() 
	{
		$result = $this->runQuery(3);
		$count = mysql_num_rows( $result );
		 
		if($count>0) 
		{
			$data = array();
			
			while($row = mysql_fetch_array($result))
			{
				$participant = new JoinParticipantList();
				$participant->update( $row );
				array_push($data, $participant );
			} 
			$this->responce->setData( $data );
			
		} else {
			$this->responce->errorMsg('No Participants.');
		}
	}
	
	
	function login() {
		$result = $this->runQuery(1);
		$count = mysql_num_rows( $result  );
		
		$this->load($result);
		
		if($count == 1) {
			$this->responce->setData( $this );
			return true;
		} else {
			$this->responce->errorMsg('Login Failed');
		}
		return false;
	}
	
	function create() 
	{
		if( $this->checkDuplicateEmail() ) 
		{
			$this->runQuery(2);
			$this->login();
			$this->responce->setData( $this );
			
			//add welcome news_feed
			/*$news = new NewsFeed();
			$news->participantId = $this->id;
			$news->addNewsTemplate($this->id, 1);
			*/
			NewsFeed::addNewsTemplate($this->id, 1);
			
		} else {
			$this->responce->errorMsg('Already Exist');
		}
	}
	
	function update($row=null) 
	{
		$this->runQuery(4);
		$this->responce->setData( $this );
	}
	
	function checkDuplicateEmail() 
	{
		$selectcnt = mysql_num_rows( $this->runQuery(0) );
		return $selectcnt == 0 ? true : false;
	}
	
	function runQuery($i) {
		switch($i) {
			case 0:
				$query = "select * from participants where Email='".$this->email."'";
				break;
				
			case 1:
				$query = "select * from participants where Email='".$this->email."' and Password='".$this->password."' ";
				break;
				
			case 2:
				$query = "INSERT INTO participants (FullName, ScreenName, Password, Email, Bio) VALUES ";
				$query .= "('".$this->fullName."', '".$this->screenName."', '".$this->password."', '".$this->email."', '".$this->bio."' )";
				break;
				
			case 3:
				$query = 'select PL.CampaignId, PL.OwnerId, P.Bio, PL.ParticipantId,  P.ScreenName, P.FullName ';
				$query .= ' from participant_list PL inner join participants P on PL.ParticipantId = P.Id';
				$query .= ' where PL.CampaignId="' .$this->campaignId .'" order by PL.CampaignId';
				break;
			
			case 4:
				$query = "update participants set FullName='".$this->fullName."', ";
				$query .= "ScreenName='".$this->screenName."', Password='".$this->password."' , Bio='".$this->bio."'  ";
				$query .= " where Id='".$this->id."' ";
				break;
		}
		
		$result = parent::execute($query);
		return $result;
	}
	 
 
}


class JoinParticipantList {
	public $compaignId = "";
	public $ownerId = "";
	public $participantId = "";
	public $bio = "";
	
	//join field
	public $screenName = "";
	public $fullName = "";
	public $photo = "aish.jpg";//"no-photo.png";
	
	private $resource;
	
	function JoinParticipantList() 
	{
		$this->resource = new Resources();
	}
	
	function update($row) 
	{		
		$this->compaignId = $row['CampaignId'];
		$this->participantId= $row['ParticipantId'];
		$this->ownerId = $row['OwnerId'];
		$this->screenName = $row['ScreenName'];
		$this->bio = $row['Bio'];
		$this->fullName = $row['FullName'];
		$this->photo = $this->resource->participantPhoto( $row['ParticipantId'] );
	}
}



?>