<?php


include "com/2gyms/core.php";
include "com/2gyms/link.php";


$add = '{"target":"ADD", "link":"http://www.google.com"}';
$get = '{"target":"GET", "id":"14"}';


$link = new Link(  );
$target = $link->target();


switch($target) {
	case "ADD":
		$link->addLink();
		echo $link->trace();
		break;
	
	case "GET":
		$link->getLink();
		echo $link->trace();
		break;	
 
}
 

?>