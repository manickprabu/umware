<?php

class Constants
{
	const news_welcome = "Welcome to 2gyms app!";
	const news_friend_join = "Your friend request has been accepted.";
	
	
}


?>