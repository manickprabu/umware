<?

final class Connection
{
    /**
     * Call this method to get singleton
     *
     * @return UserFactory
     */
    public static function instance()
    {
        static $inst = null;
        if ($inst === null) {
            $inst = new Connection();
        }
        return $inst;
    }

    /**
     * Private ctor so nobody else can instance it
     *
     */
    private function __construct()
    {
		echo 'Connection cons()';
		
		mysql_connect("localhost", "root", "") or die(mysql_error());
		//echo "Connected to MySQL<br />";
		mysql_select_db("2gymz") or die(mysql_error());
    }
}

?>