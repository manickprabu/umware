<?php

class Client {
	
	public $target = '';
	
	function Client() 
	{
		if( isset( $_POST['target'] ) )
		{
			$this->target = $_POST['target'];
		}
	}
	
	function read($test) {
	   
	   if( isset($test) ) {
			$this->target = $test;   
	   }
	   
	   if( isset( $this->target ) )
		{
			$input = json_decode( $this->target );
			return $input;
		}
   }
	
}

?>