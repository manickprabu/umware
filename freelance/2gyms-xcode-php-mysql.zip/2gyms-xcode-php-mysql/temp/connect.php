<?

mysql_connect("localhost", "root", "") or die(mysql_error());
//echo "Connected to MySQL<br />";
mysql_select_db("2gymz") or die(mysql_error());
///echo "Connected to Database";

function executeQuery($query) {
	$result = mysql_query($query) or die(mysql_error());
	return $result;
}



class Responce {
   public $status = "";
   public $data  = "";
   public $errorMessage = "";
}

class Participant {
   public $Id = "";
   public $FullName = "";
   public $ScreenName  = "";
   public $Email = "";
   public $Bio = "";
   public $Password = "";
   
   public $PhotoList = "";
   public $Photo = "aish.jpg";//"no-photo.png";
}

class ParticipantList {
	public $CompaignId = "";
	public $OwnerId = "";
	public $ParticipantId = "";	
	
	//join field
	public $ScreenName = "";
	public $Photo = "aish.jpg";//"no-photo.png";
}

class Campaign {
   public $Id = "";
   public $Name = "";
   public $Creator  = "";
   public $Members = "";
   public $Days = "";
   public $Description = "";
   public $Status = "";
}

class Resources {
	public $Source = "";
	public $Type = "";
}

?>