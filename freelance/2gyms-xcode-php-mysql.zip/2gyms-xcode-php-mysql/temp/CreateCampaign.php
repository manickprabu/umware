<?php
	include("connect.php");
	
	//process input json data
	//$appData = '{"name":"new1c2a2  323m1", "creator":"123", "members":"123", "days":"2", "description":"123", "OwnerId":"2"}';
	
   $appData = $_POST['data'];
   $input = json_decode($appData);
    
   $name = $input->{'name'};
   $creator = $input->{'creator'};
   $members = $input->{'members'};
	$days = $input->{'days'};
	$description = $input->{'description'};
	$OwnerId = $input->{'OwnerId'};
	
   
   $select = mysql_query("select * from Campaign where Name='".$name."'") or die(mysql_error());
   $selectcnt = mysql_num_rows($select);
   
   $rest = new Responce();
   if($selectcnt==0) 
   {		
	   $query = "INSERT INTO Campaign (Name, Creator, Members, Days, Description, OwnerId, Status) VALUES (";
	   $query .= "'$name', '$creator', '$members', '$days', '$description', '$OwnerId', '1')";
		
		mysql_query($query) or die(mysql_error());
		$rest->status = "sucess";
		
		//to return campaign details 
		$select = mysql_query("select * from Campaign where Name='".$name."'") or die(mysql_error());
		$rest->data = new Campaign();
		
		while($row = mysql_fetch_array($select))
		{
			$rest->data->Id = $row['Id'];
			$rest->data->Name = $row['Name'];
			$rest->data->Members = $row['Members'];
			$rest->data->Description = $row['Description'];
			$rest->data->Status = $row['Status'];
		}
   }
   
   else {
		$rest->status = "error";
		$rest->errorMessage = "Already Exist.."; 
   }
   
   echo json_encode($rest);

?>