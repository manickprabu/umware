<?php

class Friends extends Core
{
   public $id = "";
   public $participantId = "";
   public $friendId  = "";
   public $screenName = '';
   public $photo = "";
   public $bio = '';
     
	private $resource;
	 
	function Friends($test='') {
		parent::__construct();
		$this->responce = new Responce();
		$this->resource = new Resources();
		
		$this->read($test);
	}

	function read($test) {
		$input = parent::read($test);
		
		if($input)
		{
			if( property_exists($input, "target") ) 		$this->target = $input->{'target'};
			
			if( property_exists($input, "id") ) 			$this->id = $input->{'id'};
			if( property_exists($input, "participantId") ) 	$this->participantId = $input->{'participantId'}; 
			if( property_exists($input, "friendId") ) 		$this->friendId = $input->{'friendId'};
			
			//if( property_exists($input, "campaignId") ) 	$this->campaignId = $input->{'campaignId'};
		}
	}
	
	function load($select) 
	{
		while($row = mysql_fetch_array($select))
		  { 
		  	$this->participantId = $row['ParticipantId'];
			$this->friendId = $row['FriendId'];
			$this->id = $row['Id'];
		
		  }
	}
	
	function loadList($result) 
	{
		$data = array();
			
		while($row = mysql_fetch_array($result))
		{
			$friend = new Friends();
			$friend->update( $row );
			array_push($data, $friend );
		}
		return $data;
	}
	
	function update($row) 
	{
		$this->id = $row['Id'];
		$this->participantId = $row['ParticipantId'];
		$this->friendId = $row['FriendId'];
		
		$this->photo = $this->resource->participantPhoto( $row['FriendId'] );
		
		$this->screenName = $row['ScreenName'];
		$this->bio = $row['Bio'];
	}
	
	function getList()
	{
		$result = $this->runQuery(0);
		$count = mysql_num_rows( $result );
		 
		if($count>0)
		{
			$this->responce->setData( $this->loadList($result) );
		} else {
			$this->responce->errorMsg('No List Exist');
		}
	}
	
	function create() 
	{
		$selectcnt = mysql_num_rows( $this->runQuery(2) );
		if($selectcnt == 0 && $this->participantId != $this->friendId) 
		{
			//accept friend request;
			$this->runQuery(1);
			NewsFeed::addNewsTemplate($this->participantId, 2);
			
						
			//Add Nethibour friend;
			$temp = $this->participantId;
			$this->participantId = $this->friendId;
			$this->friendId = $temp;
			$this->runQuery(1);
			NewsFeed::addNewsTemplate($this->participantId, 2);
			
			//result
			$this->responce->setData( $this );
		} else {
			$this->responce->errorMsg('Already Exist');
		}
	}
	
	/*
	STATUS
	0 = done
	1 = still waiting
	
	NOTIFICATION TYPE:
	0 = CAM_JOIN 
	1 = CAM_START 
	2 = CAM_END
	3 = FRIEND_REQ
	*/
	
	function runQuery($i) 
	{
		switch($i) {
			case -1:
				$query = "select * from friends_list where ParticipantId='".$this->participantId."'";
				break;
				
			case 0:
				$query = "select FL.Id,  FL.ParticipantId, FL.FriendId, P.Bio, P.ScreenName from friends_list FL inner join participants P on FL.FriendId = P.Id where FL.ParticipantId='".$this->participantId."' order by P.ScreenName";
				break;
				
			case 1:
				$query = "INSERT INTO friends_list (ParticipantId, FriendId) VALUES ";
				$query .= "('".$this->participantId."', '".$this->friendId."' )";
				break;
				
			case 2:
				$query = "select * from friends_list where ParticipantId='".$this->participantId."' and FriendId='".$this->friendId."'";
				break;
		}
		
		$result = parent::execute($query);
		return $result;
	}
	 
 
}

?>