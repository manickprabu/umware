<?php
	include("connect.php");
	
	//process input json data
	//$appData = '{"screenName":"ddd555", "fullName":"dddd", "email":"t6es9t@test12.com", "password":"123", "bio":"biodata"}';
   $appData = $_POST['data'];
   $input = json_decode($appData);
	
   $sName = $input->{'screenName'};
   $fName = $input->{'fullName'};
   $email = $input->{'email'};
   $password = $input->{'password'};
   $bio = $input->{'bio'};
   
   $select = mysql_query("select * from Participants where Email='".$email."'") or die(mysql_error());
   $selectcnt = mysql_num_rows($select);
   
   $rest = new Responce();
   if($selectcnt==0) {
	   
	   //insert new participant
	   $query = "INSERT INTO Participants (FullName, ScreenName, Password, Email, Bio) VALUES (";
	   $query .= "'$fName', '$sName', '$password', '$email', '$bio' )";
		
		mysql_query($query) or die(mysql_error());
		
		//update resource table based on resource;
	   //$query = "UPDATE Resources set ParticipantId=100 where Id = '".$photoId."'";
		$select = mysql_query("select * from Participants where Email='".$email."'") or die(mysql_error());
		//mysql_query($query) or die(mysql_error());
		
		$rest->status = "sucess";
		$rest->data = new Participant(); 
		
		while($row = mysql_fetch_array($select))
		{
			$rest->data->Bio = $row['Bio'];
			$rest->data->Email = $row['Email'];
			$rest->data->FullName = $row['FullName'];
			$rest->data->Id = $row['Id'];
			$rest->data->ScreenName = $row['ScreenName'];
		}
		
		
   }
   else {
		//echo "Already registered.";
		$rest->status = "error";
		$rest->errorMessage = "Already Exist.."; 
   }
   
	//generate  output json
   echo json_encode($rest);
   //$json = json_encode($e);
   
   
   
   
   
   
   
   
   
   
   /*
$fullName = $_REQUEST['fullName'];

if($fullName) {
	echo 'fullName:'.$fullName;
}
else {
	echo 'Hello XCode How are you';	
}*/

?>