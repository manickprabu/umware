<?php
	include("../connect.php");
	include("data.php");
	
	//$appData = '{"CampaignId":"1"}';
    $appData = $_POST['data'];
	$input = json_decode($appData);
    
   $CampaignId = $input->{'CampaignId'};
   
   /*
   
   select PL.CampaignId, PL.OwnerId, PL.Joinee,  P.FullName from ParticipantList PL inner join Participants P on PL.OwnerId = P.Id
where PL.CampaignId = 1
order by PL.CampaignId 


$select = mysql_query("select * from ParticipantList where CampaignId='".$CampaignId."' ") or die(mysql_error());
   $selectcnt = mysql_num_rows($select);
   
*/

	$query = 'select PL.CampaignId, PL.OwnerId, PL.ParticipantId,  P.ScreenName from ParticipantList PL inner join Participants P on PL.ParticipantId = P.Id';
	$query .= ' where PL.CampaignId="' .$CampaignId .'" order by PL.CampaignId';
   
   $select = mysql_query($query) or die(mysql_error());
   $selectcnt = mysql_num_rows($select);
   
   $rest = new Responce();
   if($selectcnt>0) {
	   //echo 'login sucess';
	    $rest->status = "sucess";
		$data = array();
		
		  while($row = mysql_fetch_array($select))
		  { 
		  	$participant = new ParticipantList();
		  	 
		  	$participant->CompaignId = $row['CampaignId'];
			$participant->ParticipantId= $row['ParticipantId'];
			$participant->OwnerId = $row['OwnerId'];
			
			$participant->Photo = getProfilePhoto( $row['ParticipantId'] );
			$participant->ScreenName = $row['ScreenName'];
			
			array_push($data, $participant );
		  }
		  
		  $rest->data = $data;
		
   } else {
		//echo 'erorr login';
		$rest->status = "error"; 
		$rest->errorMessage = "No Participants...";
   }
   
   echo json_encode($rest);
   
 ?>