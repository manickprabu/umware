<?php

class ParticipantList extends Core 
{
	public $campaignId = '';
	public $participantId = '';
	public $shareType = '';
	public $ownerId = '';
	
	private $email = '';
	
	function ParticipantList($test='') 
	{
		parent::__construct();
		$this->responce = new Responce();
		
		$this->read($test);
	}
	
	function read($test) {
		$input = parent::read($test);
		
		if($input)
		{	
			if( property_exists($input, "campaignId") ) 	$this->campaignId = $input->{'campaignId'};
			if( property_exists($input, "participantId") ) 	$this->participantId = $input->{'participantId'};
			if( property_exists($input, "shareType") ) 		$this->shareType = $input->{'shareType'};
			if( property_exists($input, "ownerId") ) 		$this->ownerId = $input->{'ownerId'};
			
			if( property_exists($input, "email") ) 			$this->email = $input->{'email'};
		}
	}
	
	
	function joinMe() 
	{
		
		if( $this->checkDuplicate() ) 
		{
			$this->runQuery(1);
			$this->responce->setData( $this );
		} else {
			$this->responce->errorMsg('Already Joined');
		}
		
		$this->validateCampaign();
	}
	
	function joinWeb()
	{
		$this->participantId = $this->getParticipantId();
		$this->joinMe();
	}
	
	function checkDuplicate() 
	{
		$selectcnt = mysql_num_rows( $this->runQuery(0) );
		return $selectcnt == 0 ? true : false;
	}
	
	function getParticipantId()
	{
		$select = $this->runQuery(2);
		
		while($row = mysql_fetch_array($select))
		{ 
		  	$id = $row['Id'];
		}
		return $id;
	}
	
	
	function validateCampaign()
	{
		$campaign = new Campaign();
		$members = $campaign->getMembers($this->campaignId);
		$selectcnt = mysql_num_rows( $this->runQuery(3) );
		
		//echo ' ====>'.$this->campaignId.' = '.$members. ' = '.$selectcnt;
		if($selectcnt >= $members)
		{
			$campaign->startCampaign();
		}
	}
	
	
	function checkDuplicateEmail() 
	{
		$selectcnt = mysql_num_rows( $this->runQuery(2) );
		return $selectcnt == 0 ? true : false;
	}
	
	function runQuery($i)
	{
		switch($i) 
		{
			case 0:
				$query = "select * from participant_list where ParticipantId='".$this->participantId."' and CampaignId='".$this->campaignId. "'";
				break;
			
			case 1:
				$query = "INSERT INTO participant_list (ParticipantId, OwnerId, CampaignId, ShareType) VALUES (";
	   			$query .= "'".$this->participantId."', '".$this->ownerId."', '".$this->campaignId."', '".$this->shareType."' )";
				break;
			
			case 2:
				$query = "select * from participants where Email='".$this->email."' ";
				break;
				
			case 3:
				$query = "select * from participant_list where CampaignId='".$this->campaignId."' ";
				break;
				
		}
		
		$result = parent::execute($query);
		return $result;
	}
		
}



?>