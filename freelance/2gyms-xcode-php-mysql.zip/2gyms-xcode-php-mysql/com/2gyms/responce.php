<?php


class Responce /*extends Core */ 
{
   public $status = "";
   public $data  = "";
   public $errorMessage = "";
   
	function Responce() {
		//parent::__construct();
		print 'resources';
	}
	
	function trace() {
		json_encode($this);	
	}
	
}


?>