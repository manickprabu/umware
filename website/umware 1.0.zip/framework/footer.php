<div id="footer">
	
	<div class="row footer_inside">
		  <div class="four columns" style="width:370px;">
		    <h3>About Me</h3>
		    <p>Senior Flash/Flex Developer with over 7 years of experience in IT industry and solid experience in Live Casino Gaming, Live Video Streaming, Rich Internet Applications & Mobile App Development using flash for iOS/Android</p>
		  </div>
		  <div class="four columns">
		    <h3 class="margined_left">Footer Navigation</h3>
		    <ul class="margined_left">
		    	<li><a href="">Home</a></li>
		    	<li><a href="">Porfolio</a></li>
		    	<li><a href="">Blog</a></li>
		    	<li><a href="">Contact Me</a></li>
		    </ul>
		  </div>
		  <!--<div class="four columns">
		    <h3>Latest News</h3>
		  </div>--> 
		  <div class="four columns">
		  	<h3>Get in Touch with Us</h3>
		  	<div class="icon_phone" title="Phone">(+44) 079318 19510</div>
		    <div class="icon_mail" title="Email">manickam.prabu@gmail.com</div>	
		    <div class="icon_loc" title="Location">London City., United Kingdom</div>
		  	<div class="clear"></div>
		  	<div class="h10"></div>
		  </div>
	  </div>
	
	<div class="footer_btm">
	  	<div class="footer_btm_inner">
		  	<!--<a href="http://www.pinterest.com" target="_blank" class="icon_pinterest" title="Pinterest">Pinterest</a>-->
	      	<a href="http://www.twitter.com" target="_blank" class="icon_tweet" title="Tweeter">Tweeter</a>			
			<a href="http://www.skype.com" class="icon_skype" title="Skype">Skype</a>
		  	<a href="http://www.google.com" target="_blank" class="icon_google" title="Google+">Google+</a>
	      	<a href="http://www.facebook.com" target="_blank" class="icon_facebook" title="Facebook">Facebook</a>
  
		  	<div id="powered"><a href="portfolio.php" target="_blank">umware.</a> � 2013 &nbsp; | &nbsp; <a href="http://www.umware.com" target="_blank">UMware Creative</a></div>
		</div>
	</div>
</div>