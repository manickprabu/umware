<?php

include "com/2gyms/core.php";
include "com/2gyms/resources.php";


$upload = '{"target":"UPLOAD", "participantId":"333"}';

$resources = new Resources(  );
$target = $resources->target();

switch($target) 
{
	case "UPLOAD":
		$resources->upload();
		echo $resources->trace();
		break;
	
	case "LIST"://list by campaignId
		//$resources->getList();
		//echo $resources->trace();
		break;
}
 
?>