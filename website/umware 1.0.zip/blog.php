<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>

<title>UM Ware -Blog</title>
<link href="http://fonts.googleapis.com/css?family=Asap:400,400italic,700,700italic" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="styles/base.css" type="text/css">
<script src="scripts/jquery.1.5.1.min.js"></script>
<script src="scripts/slides.min.jquery.js"></script>
</head>

<body >
<div id="wrapper">
	<div class="container">
 	<?php include('framework/header.php'); ?>
 
 	blog
 
 	</div>
<?php include('framework/footer.php'); ?>
</div>

</body>
</html>
