<?php

class Resources extends Core 
{
	//private $RESOURCE_PATH = "http://athletepresskit.com/2gyms/data/";
	private $RESOURCE_PATH = "http://localhost/2gyms/data/";
	private $uploadDir = 'data/';
	private $type = 'image';
	
	public $source = '';
	public $participantId = '';
	
	private $resource;
	
	function Resources( $test='' ) {
		parent::__construct();
		$this->responce = new Responce();
		
		$this->read($test);
	}
	
	function read($test) {
		$input = parent::read($test);
		
		if($input)
		{
			if( property_exists($input, "participantId") ) 		$this->participantId = $input->{'participantId'};
		}
	}
	
	function upload()
	{
		if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
			//echo "Temp file uploaded. \r\n";
		} else {
			//echo "Temp file not uploaded. \r\n";
		}
		
		if ($_FILES['userfile']['size']> 300000) {
			//exit("Your file is too large."); 
		}
		
		//get file id;
		$result = $this->runQuery(1);
		while($row = mysql_fetch_array($result))
		{
			$this->source = ($row['Id'] + 1);
		}
		
		$file = basename($_FILES['userfile']['name']);
		$uploadFile = $file;
		$newName = $this->uploadDir . $this->source . $uploadFile;

		if (move_uploaded_file($_FILES['userfile']['tmp_name'], $newName)) 
		{
			$postsize = ini_get('post_max_size');   //Not necessary, I was using these
			$canupload = ini_get('file_uploads');    //server variables to see what was 
			$tempdir = ini_get('upload_tmp_dir');   //going wrong.
			$maxsize = ini_get('upload_max_filesize');
			//echo "/dir/{$file}" . "\r\n" . $_FILES['userfile']['size'] . "\r\n" . $_FILES['userfile']['type'] ;
			
			$this->source = $this->source.'.jpg';
			$this->runQuery(2);
			$this->responce->setData( $this );
		} else {
			$this->responce->errorMsg('Error While fupload.');
		}	
	}
	
	function participantPhoto($participantId) 
	{
		$list = $this->participantPhotoList($participantId, 1);
		
		$image = array_shift(array_slice($list,0,1));
			
		if( !isset($image) ) 
			return $this->RESOURCE_PATH."no-photo.png";
		
		return $image;
	}
	
	function participantPhotoList($participantId) 
	{
		$this->participantId = $participantId;
		$select = $this->runQuery(0);
		$data = array();
		
		while($row = mysql_fetch_array($select))
		{
			array_push($data, $this->RESOURCE_PATH.$row['Source'] );
		}
		
		return $data;
	}
	
	function runQuery($i) 
	{
		switch($i) {
			case 0:
				$query = "select * from resources where ParticipantId='".$this->participantId."' order by Id DESC LIMIT 5";
				break;
			
			case 1:
				$query = 'SELECT Id FROM resources ORDER BY id DESC LIMIT 1';
				break;
			
			case 2:
				$query = "INSERT INTO resources (ParticipantId, Type, Source) VALUES (";
				$query .= "'".$this->participantId."', '".$this->type."', '".$this->source."' )";
				break;
		}
		
		$result = parent::execute($query);
		return $result;
	}


}

?>