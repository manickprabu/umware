<?php

include "com/2gyms/core.php";
include "com/2gyms/notification.php";
include "com/2gyms/resources.php";

$list = '{"target":"LIST", "participantId":"2"}';
$create = '{"target":"CREATE", "type":"CAM_JOIN", "participantId":"2", "campaignId":"12", "message":"Join in pushup campaign"}';
$friend_join = '{"target":"CREATE", "type":"FRIEND_REQ", "participantId":"1", "ownerId":"2", "campaignId":"", "message":""}';
$cancel = '{"target":"CANCEL", "id":"9" }';


$notification = new Notification( );
$target = $notification->target();


switch($target) {
	case "CANCEL":
		$notification->cancel();
		echo $notification->trace();
		break;
	
	case "CREATE":
		$notification->create();
		echo $notification->trace();
		break;	
	
	case "LIST"://list by campaignId
		$notification->getList();
		echo $notification->trace();
		break;
}
 

?>