<?php

class Core 
{
	private $data;
	protected $responce;
	protected $target;
	
   function Core() 
   {
	   $con = Connection::instance();
	   
	  	//mysql_connect("localhost", "root", "") or die(mysql_error());
		//mysql_select_db("2gymz") or die(mysql_error());
		
		if( isset( $_POST['data'] ) )
		{
			$this->data = $_POST['data'];
		}
		$this->responce = new Responce();
   }
   
   function target() {
		return $this->target;
	}
	
	function trace() {
		return $this->responce->trace();
	}
   
   function read($test) {
	   
	   if( isset($test) && $test != '' ) {
			$this->data = $test;
	   }
	   
	   if( isset( $this->data ) )
		{
			$input = json_decode( $this->data );
			
			if( property_exists($input, "target") ) 		
				$this->target = $input->{'target'};
			
			return $input;
		}
   }
   
   function execute($query) {
		$result = mysql_query($query) or die(mysql_error());
		return $result;
	}
   
   function create() {
		
   }
   
   function update($row) {
	   
   }
   
   function delete() {
	   
   }
   
   function participantName($participantId)
   {
		$query = "select FullName from participants where Id='".$participantId."'";  
		while ($row = mysqli_fetch_array($result))
		{
			return $row['FullName'];           
		}
   }
   
   function hasError()
   {
	   return ($this->responce->status == 'error') ? true : false;
   }
}


class Responce {
   public $status = "";
   public $data  = "";
   public $errorMessage = "";
   
   function Responce() {

	}
	
	function trace() {
		return json_encode($this);
	}
	
	function setData($data) {
		$this->status = 'sucess';
		$this->data = $data;
	}
	
	function errorMsg($msg) 
	{
		$this->status = 'error';
		$this->errorMessage = $msg;	
	}
}



final class Connection
{
    public static function instance()
    {
        static $inst = null;
        if ($inst === null) {
            $inst = new Connection();
        }
        return $inst;
    }

    private function __construct()
    {
		//echo 'Connection cons()';
		mysql_connect("localhost", "root", "") or die(mysql_error());
		mysql_select_db("2gymz") or die(mysql_error());
		
		//mysql_connect("localhost", "athletg7", "Passw0rd!") or die(mysql_error());
		//mysql_select_db("athletg7_2gymz") or die(mysql_error());
    }
}


?>