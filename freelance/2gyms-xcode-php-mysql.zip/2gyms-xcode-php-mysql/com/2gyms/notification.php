<?php

class Notification extends Core
{
   public $id = "";
   public $participantId = "";//notification receiver
   public $campaignId  = "";
   public $type = "";
   public $message = "";	
   public $ownerId = "";		//who send this notification
      
	function Notification($test='') {
		parent::__construct();
		$this->responce = new Responce();
		
		$this->read($test);
	}

	function read($test) {
		$input = parent::read($test);
		
		if($input)
		{
			if( property_exists($input, "target") ) 			$this->target = $input->{'target'};
			
			if( property_exists($input, "id") ) 				$this->id = $input->{'id'};
			if( property_exists($input, "participantId") ) 	$this->participantId = $input->{'participantId'}; 
			if( property_exists($input, "campaignId") ) 		$this->campaignId = $input->{'campaignId'};
			if( property_exists($input, "type") ) 			$this->type = $input->{'type'};
			if( property_exists($input, "message") ) 		$this->message = $input->{'message'};
			if( property_exists($input, "ownerId") ) 		$this->ownerId = $input->{'ownerId'};
			
			
			//if( property_exists($input, "campaignId") ) 	$this->campaignId = $input->{'campaignId'};
		}
	}
	
	function load($select) 
	{
		while($row = mysql_fetch_array($select))
		  { 
		  	$this->participantId = $row['ParticipantId'];
			$this->campaignId = $row['CampaignId'];
			$this->type = $row['Type'];
			$this->id = $row['Id'];
			$this->message = $row['Message'];
			$this->ownerId = $row['OwnerId'];
		  }
	}
	
	function loadList($result) 
	{
		$data = array();
			
		while($row = mysql_fetch_array($result))
		{
			$notification = new Notification();
			$notification->update( $row );
			array_push($data, $notification );
		}
		return $data;
	}
	
	function update($row) 
	{
		$this->id = $row['Id'];
		$this->participantId = $row['ParticipantId'];
		$this->type = $row['Type'];
		$this->campaignId = $row['CampaignId'];
		$this->message = $row['Message'];
		$this->ownerId = $row['OwnerId'];
	}
	
	function getList() 
	{
		$result = $this->runQuery(0);
		$count = mysql_num_rows( $result );
		 
		if($count>0) 
		{ 
			$this->responce->setData( $this->loadList($result) );
		}
	}
	
	function create() 
	{
		$this->runQuery(2);
		$this->responce->setData( $this );
		//$this->responce->setData( '' );
	}
	
	function addNotification($type, $participantId, $message)
	{
		$this->type = $type;
		$this->participantId = $participantId;
		$this->message = $message;
		$this->status = 1;
		$this->runQuery(2);
	}
	
	function cancel() 
	{
		$this->runQuery(1);
		$this->responce->setData( '' );
	}
	
	/*
	STATUS
	0 = done
	1 = still waiting
	
	NOTIFICATION TYPE:
	0 = CAM_JOIN 
	1 = CAM_START 
	2 = CAM_END
	3 = FRIEND_REQ
	*/
	
	function runQuery($i) 
	{
		switch($i) {
			case 0:
				$query = "select * from notification where Status='1' and ParticipantId='".$this->participantId."'";
				break;
				
			case 1:
				$query = "update notification set Status='0' where Id='".$this->id."' ";
				break;
				
			case 2:
				$query = "INSERT INTO notification (ParticipantId, OwnerId, Type, CampaignId, Message, Status) VALUES ";
				$query .= "('".$this->participantId."', '".$this->ownerId."', '".$this->type."', '".$this->campaignId."', '".$this->message."'";
				$query .= ", '1' )";
				break;
				
			case 3:
				break;
		}
		
		$result = parent::execute($query);
		return $result;
	}
	 
 
}

?>