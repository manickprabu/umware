<?php
	include("connect.php");
	
	//process input json data
	//echo 'dd';
	//$appData = '{"ParticipantId":"2", "Status":"2"}';
    $appData = $_POST['data'];
	$input = json_decode($appData);
    $Id = $input->{'ParticipantId'};

   
   if( property_exists($input, "Status") ) {
		$Status = $input->{'Status'};
		//echo '----['.$Status.']-----';
		$query = "select * from Campaign where  Status='".$Status."' order by Status"; //OwnerId='".$Id."' and
   } else {
	    $query = "select * from Campaign where OwnerId='".$Id."' order by Status";
   }
   
   $select = mysql_query( $query ) or die(mysql_error());
   $selectcnt = mysql_num_rows($select);
   
   $rest = new Responce();
   if($selectcnt>0) {
	   //echo 'login sucess';
	    $rest->status = "sucess";
		$data = array();
		
		  while($row = mysql_fetch_array($select))
		  { 
		    $compaign = new Campaign();
		  	 
			 $compaign->Id = $row['Id'];
		  	$compaign->Name = $row['Name'];
			$compaign->Creator = $row['Creator'];
			$compaign->Description = $row['Description'];
			$compaign->Status = $row['Status'];
			
			array_push($data, $compaign );
		  }
		  
		  $rest->data = $data;
		
   } else {
		//echo 'erorr login';
		$rest->status = "error"; 
		$rest->errorMessage = "No Compaign...";
   }
   
   echo json_encode($rest);
   
 ?>