<?php
//$appData = $_POST['data'];
//echo $_POST['data'];
//return;


include "com/2gyms/core.php";
include "com/2gyms/participant_list.php"; 
include "com/2gyms/campaign.php"; 
 

$join = '{"target":"JOIN", "participantId":"2", "campaignId":"1", "shareType":"SMS"}';
$joinweb = '{"target":"JOIN_WEB", "email":"test", "campaignId":"14", "shareType":"WEB"}';
//$status_list = '{"target":"STATUS_LIST", "status":"2"}';
//$login = '{"target":"LOGIN", "email":"test", "password":"111"}';
//$join = '{"target":"JOIN", "name":"tese13", "creator":"123", "members":"123", "days":"2", "description":"123", "ownerId":"2"}';


$participantList = new ParticipantList(  );
$target = $participantList->target();


switch($target) {
	case "STATUS_LIST":
		$campaign->getList(true);
		echo $campaign->trace();
		break;
	
	case "JOIN":
		$participantList->joinMe();
		echo $participantList->trace();
		break;
	
	case "JOIN_WEB":
		$participantList->joinWeb();
		echo $participantList->trace();
		break;
	
	case "LIST":
		$campaign->getList();
		echo $campaign->trace();
		break;
}
 

?>