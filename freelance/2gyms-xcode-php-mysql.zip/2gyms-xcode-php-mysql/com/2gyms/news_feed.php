<?php

class NewsFeed extends Core 
{
	public $participantId = '';
	private $id = '';
	public $news = '';
	
	function NewsFeed($test='') 
	{
		parent::__construct();
		$this->responce = new Responce();
		
		$this->read($test);
	}
	
	function read($test) {
		$input = parent::read($test);
		
		if($input)
		{	
			if( property_exists($input, "news") ) 	$this->news = $input->{'news'};
			//if( property_exists($input, "id") ) 	$this->id = $input->{'id'};
			if( property_exists($input, "participantId") ) 	$this->participantId = $input->{'participantId'};
		}
	}
	
	public static function addNewsTemplate($participantId, $msg) 
	{
		$news = new NewsFeed();
		$news->participantId = $participantId;
		switch($msg) 
		{
			case 1:
				$news->news = Constants::news_welcome;
				break;
			case 2:
				$news->news = Constants::news_friend_join;
				break;
		}
		$news->addNews();
	}
	
	function addNews() 
	{
		if($this->participantId != '' && $this->news != '') 
		{
			$this->runQuery(0);
			$this->responce->setData( $this );
		}
	}
	
	function getNews() {
		
		$select = $this->runQuery(1);
		$count = mysql_num_rows( $select );
		
		if($count>0) 
		{ 
			$this->responce->setData( $this->loadList($select) );
		} else {
			$this->responce->errorMsg('No News.');
		}
		 
	}
	
	function loadList($result) 
	{
		$data = array();
			
		while($row = mysql_fetch_array($result))
		{
			$campaign = new NewsFeed();
			$campaign->update( $row );
			array_push($data, $campaign );
		}
		return $data;
	}
	
	function update($row) 
	{
		$this->id = $row['Id'];
		$this->news = $row['News'];
		$this->participantId = $row['ParticipantId'];
	}
 
	function runQuery($i) 
	{
		switch($i) 
		{
			case 0:
				$query = "INSERT INTO news_feed (ParticipantId, News) VALUES (";
	   			$query .= " '".$this->participantId." ', '".$this->news."' )";
				break;
			
			case 1:
				$query = "select * from news_feed where ParticipantId='".$this->participantId."' limit 15 ";
				break;
				
		}
		
		$result = parent::execute($query);
		return $result;
	}
		
}



?>