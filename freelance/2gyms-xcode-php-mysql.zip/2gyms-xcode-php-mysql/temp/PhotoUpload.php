<?php
	include("connect.php");
	include("data.php");

	$appData = '{"CampaignId":"1"}';
    //$appData = $_POST['data'];
	$input = json_decode($appData);
	
	$query = 'SELECT Id FROM Resources ORDER BY id DESC LIMIT 1';
	$data = mysql_query( $query ) or die(mysql_error());
	$info = mysql_fetch_array( $data );
	
	$participantId = '20';
	$type = 'image';
	$source = ($info['Id'] + 1).'.jpg';
	
	echo '-----'.$source;
	
	if(true) {
		$query = "INSERT INTO Resources (ParticipantId, Type, Source) VALUES (";
		$query .= "'$participantId', '$type', '$source' )";
		
		mysql_query($query) or die(mysql_error());
	}
	
	echo '---'. json_encode(getProfileImage( $participantId ) );

?>