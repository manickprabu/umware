<?php

include "com/2gyms/core.php";
include "com/2gyms/friends.php";
include "com/2gyms/resources.php";
include "com/2gyms/news_feed.php";
include "com/model/constants.php";

$create = '{"target":"CREATE", "participantId":"2", "friendId":"2222"}';
$list = '{"target":"LIST", "participantId":"2" }';


$friends = new Friends(  );
$target = $friends->target();

switch($target) 
{
	case "CREATE":
		$friends->create();
		echo $friends->trace();
		break;
	
	case "LIST"://list by campaignId
		$friends->getList();
		echo $friends->trace();
		break;
}
 

?>