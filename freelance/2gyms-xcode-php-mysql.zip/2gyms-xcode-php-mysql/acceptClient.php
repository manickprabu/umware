<?php

include "com/2gyms/core.php";
include "com/2gyms/participant_list.php";
include "com/2gyms/campaign.php";

$success = false;
$errorMsg = '';
$campaignId = '';
$email = '';
$selfURL = $_SERVER['PHP_SELF'];


if( isset($_GET['id']) )
{
	$campaignId = $_GET['id'];	
}

if( isset( $campaignId ) && isset($_POST['email']) )
{
	$email = $_POST['email'];
	$campaignId = $_POST['id'];
	
	$joinweb = '{"target":"JOIN_WEB", "email":"'.$email.'", "campaignId":"'.$campaignId.'", "shareType":"SMS"}';
	$participantList = new ParticipantList( $joinweb );
	
	if( $email != '' && !$participantList->checkDuplicateEmail() )
	{
		$participantList->joinWeb();
		
		if( $participantList->hasError() )
		{
			$errorMsg = 'You have already joined in this campaign.';
		} else 
			$success = true;
		//echo $participantList->trace();
		//echo $participantList->hasError();
		
	} else {
		$email = '';
		$errorMsg = 'Please enter valid email id!';
	}
}

//echo 'id:'.$campaignId;
//echo 'email:'.$email;

?>
 

<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">

<html lang="en-US">
<head>
<title>Join Campaign</title>
</head>

<style>

body
{
	padding:0px;	
}
#canvas
{
	border:1px solid;	
	background-color: gainsboro;
	font-family: sans-serif;
	color: chocolate;
	width: 100%;
	border-radius:10px;
}

#content 
{
	padding: 0px 18px 18px 18px;
}

.button
{
	width: 60%;
}

.success {
	color:green;	
	padding-top:10px;
}

.error {
	color:red;	
	padding-top:10px;
}
</style>

<body>

<div id="canvas">
	<div id="content">
<h2>2gyms</h2>
 
<?php if( $email == '') { ?>

Please enter your 2gyms's email id:<br><br>
<form name="form" action="<?php echo $selfURL ?>" method="post">
<input type="hidden" name="id" value="<?php echo $campaignId ?>"/>
<input type="text" name="email" class="button"  id="email" value="">
<input type="submit" name="submit" value="Join" />
</form>

<?php } ?>

<?php if($success) { ?>
<br>
<div class="success"> You have successfully joined! </div>
<?php }
else {
?>
<div class="error"> <?php echo $errorMsg ?> </div>
<?php }?>

</div>
</div>

</body>