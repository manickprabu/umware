<?php

	//include("connection.php");

	function getProfilePhoto($participantId) {
		$list = getProfilePhotoList($participantId, 1);
		
		$image = array_shift(array_slice($list,0,1));
			
		if( !isset($image) ) 
			return $imagePath."no-photo.png";
		
		return $image;
	}

	function getProfilePhotoList($participantId, $no = 5) {
		$query = 'select * from Resources where ParticipantId='.$participantId.' order by Id DESC LIMIT '.$no;
		$select = executeQuery( $query );
		$data = array();
		$imagePath = "http://localhost/2gymz/data/";
		
		while($row = mysql_fetch_array($select))
		{
			array_push($data, $imagePath.$row['Source'] );
		}
		
		/*if($no == 1) {
			$image = array_shift(array_slice($data,0,1));
			
			if( !isset($image) ) 
				return $imagePath."no-photo.png";
			
			return $image;
			
		} else */
			return $data;
	}


?>