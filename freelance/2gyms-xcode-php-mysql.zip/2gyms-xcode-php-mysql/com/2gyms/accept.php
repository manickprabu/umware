<?php

class NewsFeed extends Core 
{
	public $participantId = '';
	public $id = '';
	public $news = '';
	
	function NewsFeed($test='') 
	{
		parent::__construct();
		$this->responce = new Responce();
		
		$this->read($test);
	}
	
	function read($test) {
		$input = parent::read($test);
		
		if($input)
		{	
			if( property_exists($input, "news") ) 	$this->link = $input->{'news'};
			//if( property_exists($input, "id") ) 	$this->id = $input->{'id'};
			if( property_exists($input, "participantId") ) 	$this->id = $input->{'participantId'};
		}
	}
	
	
	function addNews() 
	{
		$this->runQuery(0);
		
		//get last inserted id
		$this->id = mysql_insert_id();
		$this->link = $this->linkroot.$this->id;
		
		$this->responce->setData( $this );
	}
	
	function getLink() {
		$this->runQuery(1);
		
		$select = $this->runQuery(1);
		
		while($row = mysql_fetch_array($select))
		{ 
		  	$this->link = $row['Link'];
		}
		$this->responce->setData( $this );
		
	}
	
	function runQuery($i) 
	{
		switch($i) 
		{
			case 0:
				$query = "INSERT INTO news_feed (ParticipantId, News) VALUES (";
	   			$query .= " '".$this->participantId." ', '".$this->news."' )";
				break;
			
			case 1:
				$query = "select * from links where Id='".$this->id."' ";
				break;
				
		}
		
		$result = parent::execute($query);
		return $result;
	}
		
}



?>