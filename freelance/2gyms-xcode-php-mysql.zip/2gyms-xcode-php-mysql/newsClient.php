<?php


include "com/2gyms/core.php";
include "com/2gyms/news_feed.php";


$add = '{"target":"ADD", "news":"Hello World", "participantId":"2"}';
$get = '{"target":"LIST", "participantId":"2"}';


$news = new NewsFeed(  );
$target = $news->target();


switch($target) {
	case "ADD":
		$news->addNews();
		echo $news->trace();
		break;
	
	case "LIST":
		$news->getNews();
		echo $news->trace();
		break;	
 
}
 

?>