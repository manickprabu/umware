<?php
	include("connect.php");
	
	//process input json data
	//$appData = '{"ParticipantId":"299", "CampaignId":"12", "ShareType":"SMS"}';
	
   //$appData = $_POST['data'];
   $appData = $_REQUEST['data'];
   $input = json_decode($appData);
	
   $ParticipantId = $input->{'ParticipantId'};
   $CampaignId = $input->{'CampaignId'};
   $ShareType = $input->{'ShareType'};
   
   $select = mysql_query("select * from ParticipantList where ParticipantId='".$ParticipantId."' and CampaignId='".$CampaignId. "'" ) or die(mysql_error());
   $selectcnt = mysql_num_rows($select);
   
   $rest = new Responce();
   if($selectcnt==0) {
	   $query = "INSERT INTO ParticipantList (ParticipantId, CampaignId, ShareType) VALUES (";
	   $query .= "'$ParticipantId', '$CampaignId', '$ShareType' )";
		
		mysql_query($query) or die(mysql_error());
		
		$rest->status = "sucess";
		//$rest->data = new Participant();
		//$rest->data->Id = '10';
		echo "<span style='color:green;font-size:18pt'>Thanks<br>Your Request has been accepted!!</span>";
   }
   else {
		//echo "Already registered.";
		$rest->status = "error";
		$rest->errorMessage = "Already Exist.."; 
		
		echo "<span style='color:red;font-size:18pt'>Sorry!!<br>Already Accepted this request.</span>";
   }
   
   
	//generate  output json
   //echo json_encode($rest);
   //$json = json_encode($e);
   
    
  
?>