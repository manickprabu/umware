<div class="header">
	<div class="logo">
		<h1><a href="index.php">umware.</a></h1>
		<span class="tagline">my digital wares</span>
		<div class="header_contacts ">
			<!--<div class="header_phone">+44 079318 19510</div>-->
			<div class="header_phone" style="background:none;padding-left:0px;"><script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
<script type="IN/MemberProfile" data-id="http://www.linkedin.com/pub/prabu-manickam/20/169/b72" data-format="click" data-text="Prabu Manickam" data-related="false"></script></div>
			<div class="header_mail">manickam.prabu@gmail.com</div>
		</div>
	</div>
</div>

<div class="row no_bm">
	<div class="dark_menu sixteen columns">
		<div id="menu">
			<ul>
				<li class=""><a href="index.php"><span class="home_icon"></span></a></li>
				<li class=""><a href="index.php">Home<span></span></a></li>
				<li class=""><a href="portfolio.php">Portfolio<span></span></a></li>
				<!--<li class=""><a href="blog.php">Blog<span></span></a></li-->
				<li><a href="contact.php">Contact Me</a></li>
			</ul>
		</div>
					
	</div>
</div>
