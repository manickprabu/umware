<?php

include "com/2gyms/core.php";
include "com/2gyms/campaign.php"; 
include "com/2gyms/participant_list.php"; 
 

$list = '{"target":"LIST", "ownerId":"2"}';
$status_list = '{"target":"STATUS_LIST", "status":"2"}';
$login = '{"target":"LOGIN", "email":"test", "password":"111"}';
$join = '{"target":"JOIN", "name":"tese13456789", "creator":"123", "members":"123", "days":"2", "description":"123", "ownerId":"2"}';
$active = '{"target":"ACTIVE", "id":"28"}';


$campaign = new Campaign(  );
$target = $campaign->target();

switch($target) {
	case "STATUS_LIST":
		$campaign->getList(true);
		echo $campaign->trace();
		break;
	
	case "JOIN":
		$campaign->create();
		echo $campaign->trace();
		break;	
	
	case "LIST":
		$campaign->getList();
		echo $campaign->trace();
		break;
	
	case "ACTIVE":
		$campaign->getActiveCampaign();
		echo $campaign->trace();
		break;
}
 

?>