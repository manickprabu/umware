<?php

class Campaign extends Core {
	
   public $id = "";
   public $name = "";
   public $creator  = "";
   public $members = "";
   public $days = "";
   public $description = "";
   public $status = "1";
   public $ownerId = "";
   
   private $startDate = "";
   private $endDate = "";
	
	function Campaign($test='') {
		parent::__construct();
		$this->responce = new Responce();
		
		$this->read($test);
	}
	
	function read($test) {
		$input = parent::read($test);
		
		if($input)
		{
			if( property_exists($input, "target") ) 		$this->target = $input->{'target'};
			
			//if( property_exists($input, "participantId") ) 	$this->ownerId = $input->{'participantId'};
			
			if( property_exists($input, "name") ) 		$this->name = $input->{'name'};
			if( property_exists($input, "creator") ) 	$this->creator = $input->{'creator'}; 
			if( property_exists($input, "id") ) 			$this->id = $input->{'id'};
			if( property_exists($input, "members") ) 	$this->members = $input->{'members'};
			if( property_exists($input, "days") ) 		$this->days = $input->{'days'}; 
			if( property_exists($input, "description") )$this->description = $input->{'description'}; 
			if( property_exists($input, "ownerId") ) 	$this->ownerId = $input->{'ownerId'};
			if( property_exists($input, "status") ) 		$this->status = $input->{'status'};
			
		}
	}
	
	function load($select) 
	{
		while($row = mysql_fetch_array($select))
		  { 
		  	$this->update( $row );
		  }
	}
	
	function loadList($result) 
	{
		$data = array();
			
		while($row = mysql_fetch_array($result))
		{
			$campaign = new Campaign();
			$campaign->update( $row );
			$campaign->validateCampaign();
			array_push($data, $campaign );
		}
		return $data;
	}
	
	function update($row) 
	{
		$this->id = $row['Id'];
		$this->name = $row['Name'];
		$this->members = $row['Members'];
		$this->description = $row['Description'];
		$this->status = $row['Status'];
		$this->ownerId = $row['OwnerId'];
		
		$this->days = $row['Days'];
		$this->startDate = $row['StartDate'];
		$this->endDate = $row['EndDate'];
		
		//need to optimize;
		//$this->validateCampaign();
	}
 
 	function create() 
	{
		if( $this->checkDuplicateName() ) 
		{
			$this->runQuery(1);
			$result = $this->runQuery(2);
			$this->load($result);
			$this->responce->setData( $this );
			
			$this->joinParticipantList();
		} else {
			$this->responce->errorMsg('Already Exist');
		}
		
		//$this->startCampaign();
		$this->validateCampaign();
	}
	
	function joinParticipantList()
	{
		//Auto join this owner Into this campaign
		//echo '---------id'. $this->id. '---ow'. $this->ownerId;
		$pList = new ParticipantList();
		$pList->participantId = $this->ownerId;
		$pList->ownerId = $this->ownerId;
		$pList->campaignId = $this->id;
		$pList->shareType = "OWNER";
		$pList->joinMe();
	}
	
	function getActiveCampaign()
	{
		$active = new ActiveCampaign();
		
		$result = $this->runQuery(5);
		$this->load($result);
		
		if( $this->status == '0') 
		{
			$now = strtotime( date('Y-m-d H:i:s') );//, strtotime("today"))  );
			$sDate = strtotime( $this->startDate );
			$eDate = strtotime( $this->endDate );
		
			$diff = $eDate - $now;
		
			$tomorrow = strtotime('tomorrow 00:00:00');
		
			/*
			echo $today.'<br>';
			echo $tomorrow.'<br>';
			echo date('Y-m-d H:i:s', $today).'<br>';
			echo date('Y-m-d H:i:s', $tomorrow).'<br>';
			echo $tomorrow - $today ; */
		
			$active->month = date('F', $eDate); // 1-12
			$active->days = date('d', $diff); // 1-31
			$active->hours = $tomorrow - $now;
			
			$this->responce->setData( $active );
		} else {
			$this->responce->errorMsg('No Active Campaign');
		}
	}
	
	
	function getList( $byStatus = false) 
	{
		if($byStatus)
			$result = $this->runQuery(3);
		else
			$result = $this->runQuery(8);
		
		$count = mysql_num_rows( $result );
		 
		if($count>0) 
		{ 
			$this->responce->setData( $this->loadList($result) );
		} else {
			$this->responce->errorMsg('No Campaign List.');
		}
		
	}
	
	function validateCampaign()
	{
		//echo '*******'.$this->id;
		$members = $this->getMembers($this->id);
		$selectcnt = mysql_num_rows( $this->runQuery(9) );
		//echo $selectcnt .'==='. $members.' ';
		
		if($selectcnt >= $members)
		{
			$this->startCampaign();
		}
	}
	
	function startCampaign()
	{
		//check no of participant joined
		//check minimum participant need
		//if participant count == miminum participnat = then set starting time & ending time 
		//calculate date different and update into date field
		
		$today = strtotime( date('Y-m-d', strtotime("today"))  );
		$sDate = strtotime( $this->startDate );
		$eDate = strtotime( $this->endDate );
		//echo $this->startDate;
		//echo $this->endDate;
		//echo $this->id.'----->['.$sDate.']==['.$today.']';
		
		// if '' then yet to start
		if($sDate == '' || $sDate < 0)
		{
			$sd = mktime(0,0,0,date("m"),date("d")+1,date("Y"));
			$ed = mktime(0,0,0,date("m"),date("d")+$this->days, date("Y"));
			
			$this->startDate = date("Y-m-d", $sd);
			$this->endDate = date("Y-m-d", $ed);
			
			//update start & end date into table
			//echo '<br>CAMPAIGN is Ready Start.... UPDATE START/END DATE:['. $this->startDate . ']===['. $this->endDate .']<br>';
			//echo '<br> CAMPAIGN Yet to start....<br>'.$this->id;
			$this->runQuery(6);
		} 
		else if($today >= $sDate && $today <= $eDate)
		{
			//echo '<br> CAMPAIGN STARTED & RUNNING....<br>';
			$this->runQuery(4);
		} 
		else if($today >= $eDate)
		{
			//echo '<br> CAMPAIGN END....<br>';
			$this->runQuery(7);
		} 
		else 
		{
			//echo '<br>Campaign will start soon...['.$this->startDate.']<br>';
		}
	}
	
	function getMembers($campaignId) 
	{
		$this->id = $campaignId;
		$result = $this->runQuery(5);
		$this->load($result);
		
		return $this->members;
	}
	
	function checkDuplicateName() 
	{
		$selectcnt = mysql_num_rows( $this->runQuery(2) );
		return $selectcnt == 0 ? true : false;
	}
	
	/*
	STATUS
	0 = Running campaign
	1 = Waiting for More Participant
	2 = Completed campaign
	*/
	
	function runQuery($i) 
	{
		switch($i) {
			case 0:
				$query = "select * from campaign where OwnerId='".$this->ownerId."' order by Status";
				break;
			case 1:
				$query = "INSERT INTO campaign (Name, Creator, Members, Days, Description, OwnerId, Status) VALUES ";
				$query .= "('".$this->name."', '".$this->creator."', '".$this->members."', ";
				$query .= "'".$this->days."', '".$this->description."', '".$this->ownerId."', '".$this->status."')";
				break;
			case 2:
				$query = "select * from campaign where Name='".$this->name."'";
				break;
			case 3:
				$query = "select * from campaign where Status='".$this->status."' order by Status";
				break;
				
				
			
			case 4://start campaign
				$query = "update campaign set Status='0' where Id='".$this->id."' ";
				break;
			case 5: //get campaign Member count
				$query = "select * from campaign where Id='".$this->id."'";
				break;	
			case 6://update start & enddate of the campaign
				$query = "update campaign set StartDate='".$this->startDate."',  EndDate='".$this->endDate."' where Id='".$this->id."' ";
				break;
			case 7://END campaign
				$query = "update campaign set Status='2' where Id='".$this->id."' ";
				break;
				
		
			case 8: //pull joined campaign list for this ownerId;
				$query = "select Id, Name, Creator, Members, Days, Description, Status, OwnerId, StartDate, EndDate from campaign where OwnerId='".$this->ownerId."' UNION ALL 
				select C.Id, C.Name, C.Creator, C.Members, C.Days, C.Description, C.Status, C.OwnerId, C.StartDate, C.EndDate from campaign C LEFT join participant_list PL on C.Id = PL.CampaignId where PL.ParticipantId='".$this->ownerId."' and PL.OwnerId != PL.ParticipantId order by Status";
				break;
				
				case 9:
					$query = "select * from participant_list where CampaignId='".$this->id."' ";
					break;
		}
		
		$result = parent::execute($query);
		return $result;
	}
	
}

class ActiveCampaign
{
	public $month = '';
	public $days = '';
	public $hours = '';
}

?>