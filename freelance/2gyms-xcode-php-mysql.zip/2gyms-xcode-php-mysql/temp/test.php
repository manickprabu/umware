<?php

include "../com/2gyms/core.php";
include "../com/2gyms/participant.php";

//$list = '{"target":"LIST", "campaignId":"1"}';
//$login = '{"target":"LOGIN", "email":"test", "password":"111"}';
$join = '{"target":"JOIN", "screenName":"ddd555", "fullName":"dddd", "email":"test@5test.com", "password":"123", "bio":"biodata"}';

$participant = new Participant($join);
$target = $participant->target();
//echo '----'.$target;

switch($target) {
	case "LOGIN":
		$participant->login();
		echo $participant->trace();
		break;
	
	case "JOIN":
		$participant->create();
		echo $participant->trace();
		break;	
	
	case "LIST":
		$participant->create();
		echo $participant->trace();
		break;
}



//$campaign = new Campaign();
//echo '---'.$participant->getResponce();


//print $participant->checkDuplicateEmail('test');

//echo $campaign->test();
//echo $campaign->update();


//echo json_decode($data);

//echo $participant->test();

//echo json_encode($campaign);

?>