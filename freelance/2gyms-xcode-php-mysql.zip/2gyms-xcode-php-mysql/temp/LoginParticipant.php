<?php
	include("connect.php");
	include("data.php");
	
	//process input json data
	
	//$appData = '{"email":"test", "password":"111"}';
    $appData = $_POST['data'];
	$input = json_decode($appData);
    
   $email = $input->{'email'};
   $password = $input->{'password'};
   
   $select = mysql_query("select * from Participants where Email='".$email."' and Password='".			   $password."' ") or die(mysql_error());
   $selectcnt = mysql_num_rows($select);
   
   $rest = new Responce();
   if($selectcnt==1) {
	   //echo 'login sucess';
	    $rest->status = "sucess";
		$rest->data = new Participant();
		
		  while($row = mysql_fetch_array($select))
		  { 
		  	$rest->data->Bio = $row['Bio'];
			$rest->data->Email = $row['Email'];
			$rest->data->FullName = $row['FullName'];
			$rest->data->Id = $row['Id'];
			$rest->data->ScreenName = $row['ScreenName'];
			$rest->data->Password = $row['Password'];
			
			$rest->data->PhotoList = getProfilePhotoList( $row['Id'] );
		  }
		  
		
   } else {
		//echo 'erorr login';
		$rest->status = "error"; 
		$rest->errorMessage = "Login failed...";
   }
   
   echo json_encode($rest);
   
 ?>